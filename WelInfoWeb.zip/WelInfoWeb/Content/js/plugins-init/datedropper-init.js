(function($) {
    'use strict'

    $('#datedropper').dateDropper();

})(jQuery);