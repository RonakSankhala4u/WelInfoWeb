﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WelInfoWeb.Areas.Admin.Controllers
{
    public class RoughController : Controller
    {
        // GET: Admin/Rough
        public ActionResult Index()
        {
            return View();
        }
    }
}